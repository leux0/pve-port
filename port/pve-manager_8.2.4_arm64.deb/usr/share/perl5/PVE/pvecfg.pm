package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '8.2.4';
}

sub release {
    return '8.2';
}

sub repoid {
    return '0098b77b88c86db8';
}

sub version_text {
    return '8.2.4/0098b77b88c86db8';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '8.2.4',
	'release' => '8.2',
	'repoid' => '0098b77b88c86db8',
    }
}

1;
