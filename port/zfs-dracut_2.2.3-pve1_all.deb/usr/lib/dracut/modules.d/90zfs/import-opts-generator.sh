#!/bin/sh

. /lib/dracut-zfs-lib.sh

# shellcheck disable=SC2154
echo ZPOOL_IMPORT_OPTS="$ZPOOL_IMPORT_OPTS"
