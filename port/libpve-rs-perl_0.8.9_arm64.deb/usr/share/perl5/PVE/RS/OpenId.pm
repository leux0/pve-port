package PVE::RS::OpenId;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
