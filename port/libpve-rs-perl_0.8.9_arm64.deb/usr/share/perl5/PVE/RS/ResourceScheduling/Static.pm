package PVE::RS::ResourceScheduling::Static;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
