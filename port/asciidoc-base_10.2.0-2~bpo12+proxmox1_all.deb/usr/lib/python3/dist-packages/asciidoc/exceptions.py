class EAsciiDoc(Exception):
    """Exceptions raised by the main asciidoc process"""
    pass


class AsciiDocError(Exception):
    """Exceptions raised by the asciidoc API"""
    pass
