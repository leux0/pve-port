"""Module containing metadata about asciidoc."""

VERSION = (10, 2, 0)

__version__ = '.'.join(map(str, VERSION))
