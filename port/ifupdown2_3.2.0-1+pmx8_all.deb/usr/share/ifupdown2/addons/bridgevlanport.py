#!/usr/bin/env python3
#

import os

try:
    from ifupdown2.ifupdown.utils import utils

    from ifupdown2.ifupdownaddons.modulebase import moduleBase
except ImportError:
    from ifupdown.utils import utils

    from ifupdownaddons.modulebase import moduleBase

class bridgevlanport(moduleBase):

    _modinfo = {'mhelp' : 'dummy package to override proxmox script'}
