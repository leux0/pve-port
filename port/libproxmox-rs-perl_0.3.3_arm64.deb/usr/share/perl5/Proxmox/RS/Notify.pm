package Proxmox::RS::Notify;
use base 'Proxmox::Lib::Common';
BEGIN { __PACKAGE__->bootstrap(); }
1;
