use base 'Proxmox::RS::CalendarEvent';
# Compat, Deprecated!
1
