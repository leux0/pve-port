This is contains tests for when the index and work dir differ
