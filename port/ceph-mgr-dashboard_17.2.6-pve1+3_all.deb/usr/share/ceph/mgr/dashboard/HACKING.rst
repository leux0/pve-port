Ceph Dashboard Developer Documentation
======================================

Note: The content of this file has been moved into the Ceph Developer Guide.

If you're interested in helping with the development of the dashboard, please
see ``/doc/dev/developer_guide/dash_devel.rst`` or the `online version
<https://ceph.readthedocs.io/en/latest/dev/developer_guide/dash-devel/>`_ for
details on how to set up a development environment and other development-related
topics.
